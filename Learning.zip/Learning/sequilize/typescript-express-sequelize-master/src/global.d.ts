declare namespace Express {
  export interface Response {
    boom: any
  }
}
