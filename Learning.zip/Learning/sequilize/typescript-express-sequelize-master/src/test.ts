// This is only for test demonstration purposes, remove this as soon as you implemented your own tests.
export function addTwo(input: number): number {
  input += 2
  return input
}
