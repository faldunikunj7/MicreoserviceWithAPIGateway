# Error handling with graceful shutdown in Express using TypeScript

This is a demo project for [_How to Handle Errors in Express with TypeScript_](https://www.codeconcisely.com/posts/how-to-handle-errors-in-express-with-typescript/) and [_Graceful Shutdown in Express_](https://www.codeconcisely.com/posts/graceful-shutdown-in-express/) blog posts.
