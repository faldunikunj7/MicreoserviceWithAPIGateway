const { compare } = require("bcryptjs");

const checkPassword = (password, password_hash) => compare(password, password_hash);

module.exports = { checkPassword };