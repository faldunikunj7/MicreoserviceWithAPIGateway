import { Errors } from "./errors";

export const sucees = (req, res, data, message= "success",code=200) =>{
    return res.status(code).json({data , message});
}

export const failed = (req, res, data, message= "Inte",code=500) =>{
    if(code === 500){
      return res.status(500).json({ error: Errors.SERVER_ERROR });
    }
    return res.status(code).json({data , message});
}