const { Router } = require("express");

const loginController = require("../controllers/login.controller");
const authMiddleware = require("../middlewares/auth.middleware");

const loginRoutes = Router();

loginRoutes.post("/login", loginController.login);
loginRoutes.get("/logout", authMiddleware, loginController.logout);

module.exports = { loginRoutes };
