const { Router } = require("express");
const userController = require("../controllers/user.controller");
const authMiddleware = require("../middlewares/auth.middleware");

const userRoutes = Router();
userRoutes.post("/user", userController.add);
userRoutes.post("/user/address", authMiddleware, userController.addAddress);
userRoutes.get("/user", authMiddleware, userController.get);
userRoutes.get("/user/:id", userController.find);
userRoutes.put("/user", authMiddleware, userController.update);
userRoutes.delete("/user/:id", userController.delete);

module.exports = { userRoutes };
