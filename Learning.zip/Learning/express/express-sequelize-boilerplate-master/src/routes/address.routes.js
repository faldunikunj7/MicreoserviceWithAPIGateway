const { Router } = require("express");
const addressController = require("../controllers/address.controller");

const addressRoutes = Router();
addressRoutes.post("/address", addressController.add);

module.exports = { addressRoutes };
