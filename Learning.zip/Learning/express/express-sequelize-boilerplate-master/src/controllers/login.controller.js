const User = require("../models/User");
const JwtService = require("../services/jwt.service");
const Yup = require("yup");
const { Errors } = require("../utils/errors");
const { checkPassword } = require('./../utils/hashValidate')
let loginController = {
  login: async (req, res) => {
    try {
      const schema = Yup.object().shape({
        email: Yup.string().email().required(),
        password: Yup.string().required(),
      });

      if (!(await schema.isValid(req.body)))
        return res.status(400).json({ error: Errors.VALIDATION_FAILS });

      let { email, password } = req.body;

      const user = await User.findOne({
        where: { email },
        attributes: ['id', 'name', 'email', 'password_hash']
      });
      if (!user) {
        return res.status(400).send({ error: Errors.NONEXISTENT_USER });
      }

      if (!(await checkPassword(password, user.password_hash))) {
        return res.status(401).send({ error: Errors.WRONG_PASSWORD });
      }

      const token = JwtService.jwtSign({ userId: user.id });

      return res.status(200).json({ user, token });
    } catch (error) {
      console.log(error);
      return res.status(500).json({ error: Errors.SERVER_ERROR });
    }
  },

  logout: async (req, res) => {
    try {
      JwtService.jwtBlacklistToken(JwtService.jwtGetToken(req));

      res.status(200).json({ msg: "Authorized" });
    } catch (error) {
      console.log(error);
      return res.status(500).json({ error: Errors.SERVER_ERROR });
    }
  },
};

module.exports = loginController;
