const { Sequelize } = require("sequelize");
const databaseConfig = require("../config/database");
const fs = require("fs");

const modelFiles = fs
  .readdirSync(__dirname + "/../models/")
  .filter((file) => file.endsWith(".js"));

const sequelizeService = {
  init: async () => {
    try {
      let connection = new Sequelize(databaseConfig);
      /*
        Loading models automatically
      */

      for (const file of modelFiles) {
        console.log(file);
        const model = await require(`../models/${file}`);
        model.init(connection);
      }

      modelFiles.map(async (file) => {
        const model = await require(`../models/${file}`);
        model.default.associate && model.default.associate(connection.models);
      });

      console.log("[SEQUELIZE] Database service initialized");
    } catch (error) {
      console.log("[SEQUELIZE] Error during database service initialization");
      throw error;
    }
  },
};

module.exports = sequelizeService;
