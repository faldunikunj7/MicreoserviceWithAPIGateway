var http = require('http');

function smokeFunction() {
    let i = 0
    while (75000 > i) {
        i++;
    }
    return i;
}

//create a server object:
http.createServer(function (req, res) {
    console.log(req.url);
    if (req.url === "/hello") {
        const count = smokeFunction();
        console.log("check", req.url, count);
        res.writeHead(200); //write a response to the client
        res.write("hello api " + count)
        res.end(); //end the response
    }
    else {
        console.log("other", req.url);
        res.writeHead(200); //write a response to the client
        res.write("other api")

        res.end(); //end the response
    }
}).listen(8080);