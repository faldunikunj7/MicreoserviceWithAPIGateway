import { validate } from "class-validator";
import { Request, Response } from "express";
import * as Joi from "joi";
import { CustomError } from "../middleware/custom.error";
import { UserType } from "../models/userType";
import { UserTypeMapUser } from "../models/userType_map";
import { comparePassword, encryptPassword } from "../utils/bcrypt";
import { User, userStatus } from "./../models/user";
import { JsonWebToken } from "./../utils/json-web-token";
export class AuthService {
  static login = async (req: Request, res: Response): Promise<Response> => {
    try {
      const loginValidate = Joi.object().keys({
        email: Joi.string().email().required(),
        password: Joi.string().min(8).required(),
      });

      const { error } = loginValidate.validate(req.body);
      if (error?.message) {
        return res.status(400).send({
          message: error.message,
        });
      }
      const { email, password } = req.body;
      // const userData = await User.create({
      //   email,
      //   password: await encryptPassword(password),
      //   firstName: "Nikunj",
      //   lastName: "Patel",
      //   status: userStatus.PENDING,
      // });
      // const userType = await UserType.bulkCreate(
      //   [
      //     {
      //       modelLimit: 100,
      //       type: "FEED",
      //     },
      //     {
      //       modelLimit: 100,
      //       type: "FEED",
      //     },
      //   ],
      //   { returning: true }
      // );
      // const userTypeMapData = await UserTypeMapUser.bulkCreate([
      //   {
      //     userId: userData.dataValues.id as string,
      //     userTypeId: userType[0]?.dataValues.id as string,
      //   },
      //   {
      //     userId: userData.dataValues.id as string,
      //     userTypeId: userType[1]?.dataValues.id as string,
      //   },
      // ]);

      // return res.status(400).send({
      //   message: "message",
      //   data: userTypeMapData,
      // });
      const user = await User.findOne({
        where: { email },
        include: [
          {
            model: UserTypeMapUser,
            include: [
              {
                model: UserType,
              },
            ],
          },
        ],
      });
      if (!user) {
        return res.status(400).send({ message: "Invalid email or password" });
      }
      if (user?.dataValues.status === userStatus.ACTIVE) {
        return res.status(400).send({
          message: `Your account status is ${user?.dataValues.status} , Please contact admin to active account`,
        });
      }
      if (
        !(await comparePassword(password, user?.dataValues.password as string))
      ) {
        return res
          .send({
            message: "Invalid login credentials",
          })
          .status(400);
      }
      const userData: any = user.toJSON();
      userData.userTpe = [];
      userData.UserTypeMapUsers?.forEach(
        (userType: { UserType: { type: string } }) => {
          userData.userTpe.push(userType.UserType?.type);
        }
      );
      delete userData.UserTypeMapUsers;
      const { accessToken } = await JsonWebToken.getAccessToken({
        id: user?.dataValues.id as string,
        email: user?.dataValues.email as string,
      });
      return res
        .cookie("accessToken", accessToken, { secure: true, httpOnly: true })
        .send({ user: userData })
        .status(200);
    } catch (err) {
      console.info(err);
      throw new CustomError("Internal server error", 500, err);
    }
  };
  static changePassword = async (req: Request, res: Response) => {
    const id = res.locals.jwtPayload.userId;
    const { oldPassword, newPassword } = req.body;
    if (!(oldPassword && newPassword)) {
      return res.status(400).send();
    }
    const user = await User.findOne(id);
    user.dataValues.password = await encryptPassword(newPassword);
    const errors = await validate(user);
    if (errors.length > 0) {
      return res.status(400).send(errors);
    }
    user.update({ password: user.dataValues.password });
    return res.status(204).send();
  };
}
