import cookieParser from "cookie-parser";
import cors from "cors";
import express, { Application } from "express";
import helmet from "helmet";
import "reflect-metadata";
import { AuthController } from "./controllers";
import handleError from "./middleware/custom.error";

const port = process.env.PORT;

class Server {
  public express: Application;

  constructor() {
    this.express = express();
    this.configuration();
    this.routes();
    this.start();
  }

  public configuration() {
    this.express.use(cors());
    this.express.use(helmet());
    this.express.use(express.json());
    this.express.use(cookieParser(process.env.COOKIE_PARSER_SECRET));
  }

  public async routes() {
    this.express.use(`/api/auth/`, new AuthController().router);
    this.express.use(handleError);
  }

  public start() {
    this.express.listen(port, () => {
      console.log(`server started at http://localhost:${port}`);
    });
  }
}

export default new Server().express;
