export const commonConstants = {
  badRequest: "Bad request",
  internalServerErrpr: "Internal Server Error",
  notFound: "Not found",
};
