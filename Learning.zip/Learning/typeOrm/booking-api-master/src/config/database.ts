import { config } from "dotenv";
config();
export const dbConfig = {
  password: process.env.DB_PASSWORD,
    username: process.env.DB_USERNAME,
    database: process.env.DB_INSTANCE,
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT),
    dialect: process.env.DB_TYPE,
    timezone: process.env.DB_TIMEZONE,
};

