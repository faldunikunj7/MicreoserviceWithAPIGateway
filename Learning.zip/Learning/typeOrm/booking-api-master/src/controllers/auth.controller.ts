import { Router } from "express";
import { checkAuth } from "../middleware";
import { AuthService } from "../services/auth.service";

export class AuthController {
  public router: Router;
  public authService: AuthService;

  constructor() {
    this.router = Router();
    this.routes();
  }


  public routes() {
    this.router.post("/login", AuthService.login);
    this.router.post(
      "/change-password",
      [checkAuth],
      AuthService.changePassword
    );
  }
}
