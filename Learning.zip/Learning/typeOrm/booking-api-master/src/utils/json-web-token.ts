import { sign, verify } from "jsonwebtoken";

interface GetAccessTokenParams {
  id: string;
  email: string;
}

export class JsonWebToken {
  static async getAccessToken({ id, email }: GetAccessTokenParams) {
    return {
      accessToken: sign({ id, email }, `${process.env.JWT_SECRET}`, {
        expiresIn: 3600,
      }), // Expire token 1 hours
    };
  }

  static async getRefreshToken({ id, email }: GetAccessTokenParams) {
    return {
      refreshToken: sign({ id, email }, `${process.env.JWT_SECRET}`, {
        expiresIn: 89 * 24 * 60 * 60,
      }),
    };
  }

  static async getDetailsFromAccessToken({
    accessToken,
  }: {
    accessToken: string;
  }) {
    try {
      return verify(accessToken, `${process.env.JWT_SECRET}`);
    } catch (err) {
      throw { message: "Invalid token" };
    }
  }

  static getRefreshTokenDetails({ refreshToken }: { refreshToken: string }) {
    try {
      return verify(refreshToken, `${process.env.JWT_SECRET}`);
    } catch (err) {
      throw { message: "Invalid token" };
    }
  }
}
