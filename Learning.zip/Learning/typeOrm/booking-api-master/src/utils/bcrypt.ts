import { compare, hash } from "bcrypt";
const SALT_VALUE = 10;
export const encryptPassword = async (password: string): Promise<string> => await hash(password, SALT_VALUE);

export const comparePassword = async (
  password: string,
  encryptedPassword: string
): Promise<boolean> => await compare(password, encryptedPassword);
