import { DataTypes, Model } from "sequelize";

import db from "./_instance";

export interface UserTypeAttributes {
  id?: string
  type: string
  modelLimit: number
  createdAt?: Date
  deletedAt?: Date | null
}

export class UserType extends Model<UserTypeAttributes> {

}

UserType.init(
    {
        id: {
            type: DataTypes.UUID,
            primaryKey: true,
            allowNull: false,
            defaultValue: DataTypes.UUIDV4
        },
        type: {
            type: DataTypes.STRING,
            allowNull: false
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW,
        },
        modelLimit:{
            type: DataTypes.INTEGER,
            defaultValue: 100
        }
    },
    {
        sequelize: db,
        paranoid: true,
        timestamps: true,
        freezeTableName: true,
        tableName: "UserType"
    }
);
