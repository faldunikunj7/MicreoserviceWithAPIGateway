import Sequelize from "sequelize";
import { dbConfig } from "../config/database";

const sequelize = new Sequelize.Sequelize(
  dbConfig.database as string,
  dbConfig.username as string,
  dbConfig.password as string,
  {
    dialect: dbConfig.dialect as "mssql",
    timezone: dbConfig.timezone,
    logQueryParameters: false,
    logging: false,
  }
);

export default sequelize;
