import { DataTypes, Model } from "sequelize";
import { User } from "./user";
import { UserType } from "./userType";

import db from "./_instance";

export interface UserTypeMapUserAttributes {
  id?: string;
  userId: string;
  userTypeId: string;
  createdAt?: Date;
  updatedAt?: Date;
  deletedAt?: Date | null;
}

export class UserTypeMapUser extends Model<UserTypeMapUserAttributes> {}

UserTypeMapUser.init(
  {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      allowNull: false,
      defaultValue: DataTypes.UUIDV4,
    },
    userId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: "Users",
        key: "id",
      },
    },
    userTypeId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: "UserType",
        key: "id",
      },
    },
  },
  {
    sequelize: db,
    paranoid: true,
    timestamps: true,
    freezeTableName: true,
    tableName: "UserTypeMapUser",
  }
);

UserTypeMapUser.belongsTo(User, { foreignKey: "userId" });
UserTypeMapUser.belongsTo(UserType, { foreignKey: "userTypeId" });
UserType.hasMany(UserTypeMapUser, { foreignKey: "userTypeId" });
User.hasMany(UserTypeMapUser, { foreignKey: "userId" });

// export default UserTypeMapUsers;
