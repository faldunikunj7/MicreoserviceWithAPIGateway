import { DataTypes, Model } from "sequelize";
import db from "./_instance";

export enum userStatus {
  ACTIVE,
  DE_ACTIVE,
  PENDING,
}

export interface UserAttributes {
  id?: string;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  createdAt?: Date;
  updatedAt?: Date;
  deletedAt: Date | null;
  status: userStatus;
}

export interface TokenAttributes {
  data: UserAttributes;
  message: string;
}

export interface LoginAttributes {
  email: string;
  password: string;
}

export interface EmailAttributes {
  email: string;
  fullName: string;
}

export class User extends Model<UserAttributes> {}

User.init(
  {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      allowNull: false,
      defaultValue: DataTypes.UUIDV4,
    },
    firstName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    lastName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    status: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: "PENDING",
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    deletedAt: {
      type: DataTypes.DATE,
    },
    updatedAt: {
      type: DataTypes.DATE,
    },
  },
  {
    sequelize: db,
    paranoid: true,
    timestamps: true,
    freezeTableName: true,
    tableName: "Users",
  }
);
