export interface __Error {
  name: string;
  status: number;
}
