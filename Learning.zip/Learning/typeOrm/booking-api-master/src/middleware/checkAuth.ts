import { NextFunction, Request, Response } from "express";
import { JwtPayload, verify } from "jsonwebtoken";

export interface JwtPayloadExtend extends JwtPayload {
  userId: number;
  username: string;
}

// export const checkAuth = (
//   expressRequest: Request,
//   res: Response,
//   next: NextFunction
// ) => {
//   const req = expressRequest as RequestCustom;
//   const token = req.signedCookies.accessToken;
//   let jwtPayload;
//   try {
//     jwtPayload = <JwtPayloadExtend>(
//       verify(token, process.env.JWT_SECRET as string)
//     );
//   } catch (error) {
//     return res.send({ message: "Invalid accesss token" }).status(403);
//   }
//   req["user"] = jwtPayload;
//   next();
// };


export const checkAuth = (
  expressRequest: Request,
  res: Response,
  next: NextFunction
) => {
  const token = expressRequest.signedCookies.accessToken;
  let jwtPayload;
  try {
    jwtPayload = <JwtPayloadExtend>(
      verify(token, process.env.JWT_SECRET as string)
    );
  } catch (error) {
    return res.send({ message: "Invalid accesss token" }).status(403);
  }
  res.locals.jsonwebtoken = jwtPayload;
  return next();
}