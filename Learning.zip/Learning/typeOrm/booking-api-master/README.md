

# Prerequisites
- Node
- SQL Databse

# Project setup
```
npm install
```

# Rename .env.example to env

Change `NODE_ENV` to `prod` if you want to test building prod version locally.

```yaml
NODE_ENV=dev
DB_TYPE=postgres
DB_HOST=localhost
DB_PORT=5432
DB_USERNAME=postgres
DB_PASSWORD=postgres
DB_INSTANCE=postgres
DB_SYNCHRONIZE=true
JWT_SECRET=secret
```


# Start dev server and seed database with initial data
```
npm run dev
```


# Lint code to detect issues
```
npm run lint
```
# Build code for production
Make sure your `NODE_ENV` is set to `prod`.
```
npm run build
```

# Login to receive jwt token for subsequent request

```bash
POST http://localhost:3000/api/auth/login
```
```json
{
    "username": "admin",
    "password": "admin"
}
```
### Use token from login repsone in the auth header for subsequent request
```
generated-token
```

