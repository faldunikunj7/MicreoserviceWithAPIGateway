export default
{
  helloWorld: 'Hello V2X'
};
