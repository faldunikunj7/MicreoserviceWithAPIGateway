const { connect, StringCodec } = require("nats");
const { Message, Stan } = require('node-nats-streaming');


const servers =
    { servers: ["0.0.0.0:4222", "0.0.0.0:4222"], name: "nats-test" }
    // { port: 4222 },
    // { "localhost": "localhost" }
    ;
const main = async () => {
    try {
        const nc = await connect(servers);
        const client = await nc.jetstream();
        // create a codec
        const sc = StringCodec();
        // create a simple subscriber and iterate over messages
        // matching the subscription
        const sub = nc.subscribe("hello");
        (async () => {
            for await (const m of sub) {
                console.log(`[${sub.getProcessed()}]: ${sc.decode(m.data)}`);

            }
            console.log("subscription closed");
        })();

        // nc.publish("hello", sc.encode("world"));
        nc.publish("hello", sc.encode("again"));

        console.log(`connected to ${nc.getServer()}`);
        // this promise indicates the client closed
        // const done = nc.closed();
        // do something with the connection

        // close the connection
        // await nc.close();
        // check if the close was OK
        const err = await done;
        if (err) {
            console.log(`error closing:`, err);
        }
    } catch (err) {
        console.log(`error connecting to`);
    }
}

main().then().catch(err => console.log(err));
// const sc = require('node-nats-streaming').connect('my_cluster', 'NCXA6LRZZZS55FJ2ZP6W2OPHYL334NZ4Z2PF5E3YKFSTYUAQ7POBPWWB')

// sc.on('connect', () => {
//   // Simple Publisher (all publishes are async in the node version of the client)
//   sc.publish('foo', 'Hello node-nats-streaming!', (err, guid) => {
//     if (err) {
//       console.log('publish failed: ' + err)
//     } else {
//       console.log('published message with guid: ' + guid)
//     }
//   })

// Subscriber can specify how many existing messages to get.
// const opts = sc.subscriptionOptions().setStartWithLastReceived()
// const subscription = sc.subscribe('foo', opts)
// subscription.on('message', (msg) => {
//     console.log('Received a message [' + msg.getSequence() + '] ' + msg.getData())
// })

// // After one second, unsubscribe, when that is done, close the connection
// setTimeout(() => {
//     subscription.unsubscribe()
//     subscription.on('unsubscribed', () => {
//         sc.close()
//     })
// }, 1000)
// })

// sc.on('close', () => {
//     process.exit()
// })