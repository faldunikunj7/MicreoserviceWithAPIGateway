export enum Subjects {
  ProductCreated = 'phoenix.product:created',
  // TicketUpdated = 'ticket:updated',
}
