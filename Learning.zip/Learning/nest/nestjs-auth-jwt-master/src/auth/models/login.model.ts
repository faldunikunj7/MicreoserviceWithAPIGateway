export class Login {
  email: string;
  password: string;
  ipAddress: string;
  clientId: string;
}
