import {
  BadRequestException, Body, Controller, HttpStatus, InternalServerErrorException, Logger, Post
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';

import { MapperService } from '../shared/mapper/mapper.service';
import { GetOperationId } from '../shared/utils/get-operation-id';
import { User } from './models/user.model';
import { UserService } from './user.service';
import { RegisterUserVm } from './view-models/register-user-vm.model';
import { UserVm } from './view-models/user-vm.model';

@Controller()
export class UserController {
  constructor(
    private readonly userService: UserService,
    private readonly mapperService: MapperService,
  ) {
    this.mapperService.createMap(RegisterUserVm.name, User.name);
    this.mapperService
      .createMap(User.name, UserVm.name)
      .forSourceMember('_id', opts => opts.ignore())
      .forSourceMember('password', opts => opts.ignore())
      .forSourceMember('__v', opts => opts.ignore());
  }

  @Post('user/register')
  @ApiResponse({ status: HttpStatus.CREATED, type: UserVm })
  @ApiResponse({ status: HttpStatus.BAD_REQUEST, type: BadRequestException })
  @ApiOperation(GetOperationId('User', 'Register'))
  async registerClient(@Body() registerVm: RegisterUserVm): Promise<UserVm> {
    const { email } = registerVm;
    console.log(email );
    
    let exist;
    try {
      exist = await this.userService.findOne({ email });
    } catch (error) {
      Logger.error(error);
      throw new InternalServerErrorException('Error while creating user');
    }

    if (exist) {
      throw new BadRequestException(`${email} already exists`);
    }    
    // const userModel = this.mapperService.map<User>(
    //   registerVm,
    //   RegisterUserVm.name,
    //   User.name
    // );
    // console.log(userModel);
    const userModel: User = {
      email,
      password: registerVm.password,
      firstName: registerVm.firstName,
      lastName: registerVm.lastName,
      gender: registerVm.gender,
      lastLoginDate: undefined,
      buildSchema: undefined
    }
    const newUser = await this.userService.register(userModel);
    return this.mapperService.map<UserVm>(newUser, User.name, UserVm.name);
  }
}
