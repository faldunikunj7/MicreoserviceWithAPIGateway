export enum Gender {
  Male = 'Male',
  Female = 'Female',
  Other = 'Other',
}
