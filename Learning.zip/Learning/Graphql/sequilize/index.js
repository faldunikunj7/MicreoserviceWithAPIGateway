const { Sequelize } = require('sequelize');

// Option 1: Passing a connection URI
// const sequelize = new Sequelize('sqlite::memory:') // Example for sqlite
const sequelize = new Sequelize('postgres://postgres:12345678@localhost:5432/database_development') // Example for postgres

const data = sequelize.query('SELECT * FROM User');
console.log(data.then((res=>{console.log(res);})).catch(err=>{
    console.log(err);
}));