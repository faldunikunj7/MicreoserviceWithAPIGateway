import { PubSub } from 'apollo-server-express';

export const pubsub = new PubSub();
export default pubsub;
